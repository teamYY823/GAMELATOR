/*主界面按钮*/
export default () => ({
  game: [
    [
      {
        color: "lightgreen",
        type: "solvelevel",
        txt: "提示"
      },
      null,
      {
        color: "darkred",
        type: "resetlevel",
        txt: "重做"
      }
    ],
    [null, null, null],
    [
      {
        color: "lightblue",
        type: "menu",
        txt: "菜单"
      },
      null,
      null
    ]
  ],
  
  //菜单栏按钮设置
  menu: [
    [
      {
        type: "",
        txt: "",
        
      },
      {
    	color: "lightorange",
        type: "",
        txt: "",
        
      },
      {
        type: "",
        txt: ""
      }
    ],
    [
      {
        color: "lightblue",
        type: "changelevel",
        params: { value: -1 },
        txt: "-"
      },
      {
        color: "darkblue",
        type: "showlevel",
        txt: "0"
      },
      {
        color: "lightblue",
        type: "changelevel",
        params: { value: 1 },
        txt: "+"
      }
    ],
    [
      {
        color: "darkred",
        type: "continuegame",
        txt: "开始"
      },
      null,
      null
    ]
  ]
});
