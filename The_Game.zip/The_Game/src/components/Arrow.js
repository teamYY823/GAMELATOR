import React from "react";
import "../styles/arrow.css";
/*提示过程箭头动作设置*/
const Arrow = () => (
  <div className="container_arrow">
    <div className="chevron" />
  </div>
);

export default Arrow;
